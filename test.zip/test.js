const { Client } = require('discord.js-selfbot-v13');
const client = new Client({ ws: { properties: { $browser: "Discord iOS" }} });
const time = [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000];

client.on('messageCreate', message => {
  const content = message.content.toLocaleLowerCase()
  if (content === 'السلام عليكم') {
      setTimeout(() => {
      message.channel.reply("وعليكم السلام");
    }, time[Math.floor(Math.random() * time.length)]);
  }
});
client.on('messageCreate', message => {
  const content = message.content.toLocaleLowerCase()
  if (content === 'Welcome , Enjoy in Pact <:Emaj6:122222177191092379197510>') {
      setTimeout(() => {
      message.channel.send("Welcome , Enjoy in Pact <:Emaj62222:1177191092379197510>");
    }, time[Math.floor(Math.random() * time.length)]);
  }
});
client.on('messageCreate', message => {
  const content = message.content.toLocaleLowerCase()
  if (content === 'صباح الخير') {
      setTimeout(() => {
      message.reply("صباح النور");
    }, time[Math.floor(Math.random() * time.length)]);
  }
});
client.on('messageCreate', message => {
  const content = message.content.toLocaleLowerCase()
  if (content === 'هاي') {
      setTimeout(() => {
      message.channel.send("هااايااات");
    }, time[Math.floor(Math.random() * time.length)]);
  }
});
client.on('messageCreate', message => {
  const content = message.content.toLocaleLowerCase()
  if (content === 'كت؟') {
      setTimeout(() => {
      message.channel.reply("قووو");
    }, time[Math.floor(Math.random() * time.length)]);
  }
});
client.on('messageCreate', message => {
  if (message.author.id === '1106752869874552842') return
  if(message.channel.id === '1197305651613925449') {
    message.react('<:Emaj6:1177191092379197510>')// 
  }
  });

client.on('ready', async () => {
  console.log(`${client.user.username} is ready!`);
})

client.login('MTE5NzYyNTAwNzg0OTg2NTI3OQ.GAWTof.Cuh3EVWprm6l4xDKLmgBIB5ZCVV2rP1Rpz7nUI','MTE4MDYwNTY5NDc5MDA3ODQ4Nw.GUwHAc.7ke0nWmJLg-Qqt8bhXm-pNcGgAhYHYHbvq0KLY');
